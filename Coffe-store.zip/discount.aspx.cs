﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coffe_store
{
    public partial class discount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

            String sql;
            sql = "select * from discode";

            SqlCommand comm = new SqlCommand(sql, conn);

            conn.Open();

            SqlDataReader reader = comm.ExecuteReader();

            GridView1.DataSource = reader;
            GridView1.DataBind();

            reader.Close();
            conn.Close();
        }

        protected void insertcode_Click(object sender, EventArgs e)
        {
        SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

            string sql;
            sql = "insert into discode(code,ratio, codeby ) values ( '" + codename.Text + "' , '" + percent1.SelectedValue + "' , '" + Convert.ToString(Session["username"]) + "')";

            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            comm.ExecuteNonQuery();

            label1.Text = "sucessfull inserted ";
        }


    }
}