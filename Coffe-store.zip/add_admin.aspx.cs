﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coffe_store
{
    public partial class add_admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

            string sql;
            sql = "insert into users(username,password,role) values ( '" + username.Text + "' , '" + password.Text + "' , '" +  "admin" + "')";

            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            comm.ExecuteNonQuery();
            username.Text = "";
            password.Text = "";
            password2.Text = "";

            massage.Text = "sucessfull inserted ";
        }
    }
}