﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coffe_store
{
    public partial class Buy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
            string sql;
            sql = "SELECT * FROM items where Id ='" + Request.QueryString["Id"] + "' ";
            SqlCommand comm = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();

            if (reader.Read())
            {
                itemsname.Text = Convert.ToString(reader["name"]);
                itemsdes.Text = Convert.ToString(reader["descreption"]);
                itemsprice.Text = Convert.ToString(Convert.ToInt32(reader["price"]));
                itemsimg.ImageUrl = "~//imges/items//" + (string)reader["imgefilename"]; ;

            }

            reader.Close();
            conn.Close();
        }

        protected void codedis_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
            string sql;
            sql = "SELECT * FROM discode where code ='" + discode1.Text + "' ";
            SqlCommand comm = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();
            
            if (reader.Read())
            {
                
                double a = Convert.ToDouble(reader["ratio"]);
                int b = Convert.ToInt32(itemsprice.Text);
                double d = (a * b);
                newprice1.Text = Convert.ToString(d);



            }
            else {
                Label1.Text = "This code does not exist";
            }

            reader.Close();
            conn.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           if (newprice1.Text != "")
            {
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
                double itemsprice1 = Convert.ToDouble(newprice1.Text);
                int itemsq1 = Convert.ToInt32(itemsq.Text);
                double totalprice = Convert.ToDouble((itemsprice1 * itemsq1));
                string sql;
                sql = "insert into orders(itemid,itemname,username,quantity, totalprice) values ( '" + Request.QueryString["Id"] + "' , '" + itemsname.Text + "' , '" + Convert.ToString(Session["username"]) + "'  , '" + itemsq.Text + "' ,'" + Convert.ToString(totalprice) + "')";

                SqlCommand comm = new SqlCommand(sql, conn);
                conn.Open();
                comm.ExecuteNonQuery();
                Label1.Text = "sucessfull purchase , thank you for vist our store ";
            }
           else
            {
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
                double itemsprice1 = Convert.ToDouble(itemsprice.Text);
                double itemsq1 = Convert.ToDouble(itemsq.Text);
                double totalprice = Convert.ToDouble((itemsprice1 * itemsq1));
                string sql;
                sql = "insert into orders(itemid,itemname,username,quantity, totalprice) values ( '" + Request.QueryString["Id"] + "' , '" + itemsname.Text + "' , '" + Convert.ToString(Session["username"]) + "'  , '" + itemsq.Text + "' ,'" + Convert.ToDouble(totalprice) + "')";

                SqlCommand comm = new SqlCommand(sql, conn);
                conn.Open();
                comm.ExecuteNonQuery();
                Label1.Text = "sucessfull purchase , thank you for vist our store ";
            }

        }
    }
}