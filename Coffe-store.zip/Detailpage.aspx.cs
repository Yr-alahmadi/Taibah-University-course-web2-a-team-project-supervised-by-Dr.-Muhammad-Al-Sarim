﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coffe_store
{
    public partial class Detailpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
            string sql;
            sql = "SELECT * FROM items where Id ='" + Request.QueryString["Id"] + "' ";
            SqlCommand comm = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();

            if (reader.Read())
            {
                itemsname.Text = Convert.ToString(reader["name"]);
                itemsdes.Text = Convert.ToString(reader["descreption"]);
                itemsprice.Text = Convert.ToString(Convert.ToInt32(reader["price"]));
                itemsimg.ImageUrl = "~//imges/items//" + (string)reader["imgefilename"]; ;

            }
            
            reader.Close();
            conn.Close();
        }
    }
}