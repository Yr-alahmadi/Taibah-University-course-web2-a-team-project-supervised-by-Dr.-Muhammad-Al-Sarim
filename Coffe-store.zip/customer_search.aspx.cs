﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Net.Mime.MediaTypeNames;

namespace coffe_store
{
    public partial class customer_search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void search_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
            string sql = "SELECT * FROM users where username ='" + username.Text + "'  ";
            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();
            if (reader.Read())
            {
            password.Text = reader["password"].ToString();
            email.Text = reader["email"].ToString();
                number.Text = reader["number"].ToString();
                age.Text = reader["age"].ToString();
                role.Text = reader["role"].ToString();
                registdate.Text = reader["registdate"].ToString();
                massage.Text = "Success";
            }
            else
            {
                massage.Text = "Name not found";
            }
            reader.Close(); conn.Close();
        }

        protected void update_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
            string sql = "update  users set password ='" + password.Text + "' , role = '" + role.Text + "' , email = '" + email.Text + "' , number = '" + Convert.ToInt32(number.Text) + "'  , age = '" + Convert.ToInt32(age.Text) + "'  where username ='" + username.Text + "'";

            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();
            password.Text = "";
            email.Text = "";
            number.Text = "";
            age.Text = "";
            role.Text = "";
            registdate.Text = "";
            massage.Text = "Success";
            reader.Close(); conn.Close();
        }

        protected void delet_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
            string sql = "delete from users where  username ='" + username.Text + "' ";
            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();
            
                password.Text = "";
                email.Text = "";
                number.Text = "";
                age.Text = "";
                role.Text = "";
                registdate.Text = "";
                massage.Text = "Success";

            reader.Close(); conn.Close();
        }
    }
}