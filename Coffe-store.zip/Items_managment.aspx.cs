﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace coffe_store
{
    public partial class Items_managment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void insert_Click(object sender, EventArgs e)
        {
            if (itemimage1.FileName != "")
            {
                string imgfile = itemimage1.FileName;
                itemimage1.PostedFile.SaveAs(Server.MapPath("imges/items") + "\\" + imgfile);


                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

                string sql;
                sql = "insert into items(name,descreption,price,quantity, discountYes,discountNo,category,imgefilename) values ( '" + itemname.Text + "' , '" + itemdescreption.Text + "' , '" + itemprice.Text + "'  , '" + itemquantity.Text + "' ,'" + Yes.Checked + "' ,'" + No.Checked + "' ,'" + category.SelectedValue + "' ,'" + imgfile + "' )";

                SqlCommand comm = new SqlCommand(sql, conn);
                conn.Open();
                comm.ExecuteNonQuery();
                itemname.Text = "";
                itemdescreption.Text = "";
                itemprice.Text = "";
                itemquantity.Text = "";


                massage.Text = "sucessfull inserted ";
            }
            else
            {
                massage.Text = "Please upload a image";
            }
        }

        protected void delet_Click(object sender, EventArgs e)
        {
            if (itemname.Text != "")
            {
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
            string sql = "delete from items where  name ='" + itemname.Text + "' ";
            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();

            itemname.Text = "";
            massage.Text = "Success";

            reader.Close(); conn.Close();
            }
            {
                massage.Text = "Please enter item name";
            }
        }

        protected void update_Click(object sender, EventArgs e)
        {
            if (itemname.Text != "")
            {
                string imgfile = itemimage1.FileName;
                itemimage1.PostedFile.SaveAs(Server.MapPath("imges/items") + "\\" + imgfile);


                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

                string sql;
                 sql = "update  items set descreption ='" + itemdescreption.Text + "' , price = '" + itemprice.Text + "' , quantity = '" + itemquantity.Text + "'  , discountYes = '" + Yes.Checked + "'  , discountNo = '" + No.Checked + "'  , category = '" + category.SelectedValue + "'  , imgefilename = '" + imgfile + "'  where name ='" + itemname.Text + "'";

                SqlCommand comm = new SqlCommand(sql, conn);
                conn.Open();
                comm.ExecuteNonQuery();
                itemname.Text = "";
                itemdescreption.Text = "";
                itemprice.Text = "";
                itemquantity.Text = "";


                massage.Text = "sucessfull inserted ";
            }
            else
            {
                massage.Text = "Please enter item name to update";
            }
        }
    }
    }
