﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coffe_store
{
    public partial class admin_report : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

            String sql;
            sql = "select id as orderID,itemid as ItemID,username as orderBy,buydate as Date,totalprice as TotalPrice from orders";

            SqlCommand comm = new SqlCommand(sql, conn);

            conn.Open();

            SqlDataReader reader = comm.ExecuteReader();

            GridView1.DataSource = reader;
            GridView1.DataBind();

            reader.Close();
            conn.Close();
        }

        protected void searchbyname_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

            String sql;
            sql = "SELECT * FROM orders where username ='" + searchbyname.Text + "'  ";

            SqlCommand comm = new SqlCommand(sql, conn);

            conn.Open();

            SqlDataReader reader = comm.ExecuteReader();

            GridView3.DataSource = reader;
            GridView3.DataBind();

            reader.Close();
            conn.Close();
        }
    }
}