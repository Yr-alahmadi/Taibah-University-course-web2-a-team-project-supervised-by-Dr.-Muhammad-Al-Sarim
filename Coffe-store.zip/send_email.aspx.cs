﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

namespace coffe_store
{
    public partial class send_email : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            var mail = new MailMessage();
            mail.From = new MailAddress("aimanturanil@ gmail.com");
            mail.To.Add(email.Text); // receiver email address
            mail.Subject = "Coffe store";
            mail.IsBodyHtml = true;
            mail.Body = message.Text;
            SmtpServer.Port = 587;
            SmtpServer.UseDefaultCredentials = false;
            SmtpServer.Credentials = new System.Net.NetworkCredential("aimanturani@ gmail.com", "123d");
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);
            massage.Text = "Email sent.";

        }
    }
}