﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coffe_store
{
    public partial class signin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");
           string sql = "SELECT * FROM users where username ='" + username.Text + "' and password ='" + password.Text + "'  ";
            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader reader = comm.ExecuteReader();
            if (reader.Read())
            {
                Session["role"] = Convert.ToString(reader["role"]);
                Session["username"] = Convert.ToString(reader["username"]);
                Session["userId"] = Convert.ToString(reader["Id"]);


                if (Convert.ToString(Session["role"]) ==  "admin")            

                Server.Transfer("Home_admin.aspx");

                               else
                        Server.Transfer("Home_customer.aspx");
         
             }
            else
            { Label1.Text = "Incorrect data, wrong username or password"; }
            reader.Close(); conn.Close();

        }
    }
}