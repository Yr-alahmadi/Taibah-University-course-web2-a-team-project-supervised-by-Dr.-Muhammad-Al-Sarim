﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coffe_store
{
    public partial class My_purchase_aspx : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\t-r19\\Documents\\coffeStore.mdf;Integrated Security=True;Connect Timeout=30");

            String sql;
            sql = "select * from orders where username ='" + Convert.ToString(Session["username"]) + "'  ";

            SqlCommand comm = new SqlCommand(sql, conn);

            conn.Open();

            SqlDataReader reader = comm.ExecuteReader();

            Gridview12.DataSource = reader;
            Gridview12.DataBind();

            reader.Close();
            conn.Close();
        }
    }
}